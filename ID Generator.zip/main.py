from tkinter import *
from tkinter import ttk
import tkinter.messagebox
import pyperclip

root = Tk()
root.title("")
root.geometry("175x250")

menubar = Menu(root)
root.config(menu=menubar)

CategoryMenu = Menu(menubar, tearoff=False)
Format = Menu(menubar, tearoff=False)
Month = Menu(menubar, tearoff=False)

MIDInput = ttk.Entry(root, width=15, textvariable=StringVar())

MUniqueNumber = IntVar(value=0)
MCategory = IntVar(value=0)
MFormat = IntVar(value=0)
MYear = 23
MMonth = IntVar(value=0)

menubar.add_cascade(label='Category', menu=CategoryMenu, underline=0)
CategoryMenu.add_radiobutton(label='Morbid', command=lambda: MCategory.set(1))
CategoryMenu.add_radiobutton(label='Generally Funny', command=lambda: MCategory.set(2))
CategoryMenu.add_radiobutton(label='Political', command=lambda: MCategory.set(3))
CategoryMenu.add_radiobutton(label='Gaming', command=lambda: MCategory.set(4))
CategoryMenu.add_radiobutton(label='Template', command=lambda: MCategory.set(5))
CategoryMenu.add_radiobutton(label='Historical', command=lambda: MCategory.set(6))
CategoryMenu.add_radiobutton(label='Relatable', command=lambda: MCategory.set(7))
CategoryMenu.add_radiobutton(label='B-Class', command=lambda: MCategory.set(8))
CategoryMenu.add_radiobutton(label='A-Class', command=lambda: MCategory.set(9))

menubar.add_cascade(label='Format', menu=Format, underline=0)
Format.add_radiobutton(label='Image', command=lambda: MFormat.set(1))
Format.add_radiobutton(label='GIF', command=lambda: MFormat.set(2))
Format.add_radiobutton(label='Video', command=lambda: MFormat.set(3))

menubar.add_cascade(label='Month', menu=Month, underline=0)
Month.add_radiobutton(label="January", command=lambda: MMonth.set(1))
Month.add_radiobutton(label="February", command=lambda: MMonth.set(2))
Month.add_radiobutton(label="March", command=lambda: MMonth.set(3))
Month.add_radiobutton(label="April", command=lambda: MMonth.set(4))
Month.add_radiobutton(label="May", command=lambda: MMonth.set(5))
Month.add_radiobutton(label="June", command=lambda: MMonth.set(6))
Month.add_radiobutton(label="July", command=lambda: MMonth.set(7))
Month.add_radiobutton(label="August", command=lambda: MMonth.set(8))
Month.add_radiobutton(label="September", command=lambda: MMonth.set(9))
Month.add_radiobutton(label="October", command=lambda: MMonth.set(10))
Month.add_radiobutton(label="November", command=lambda: MMonth.set(11))
Month.add_radiobutton(label="December", command=lambda: MMonth.set(12))

def MemeIDPopUp():
    MUniqueNumber.set(int(MIDInput.get()))
    MiDn = "".join(str(var) for var in (MUniqueNumber.get(), MCategory.get(), MFormat.get(), MYear, MMonth.get()))
    pyperclip.copy(MiDn)  # Copy the ID to clipboard
    tkinter.messagebox.showinfo('ID Generated', MiDn)

Label(root, text="ID Generator", width=15, height=3, font="Helvetica").grid(column=0, row=0)
Label(root, text="Unique Number", width=15, height=2, font="Helvetica").grid(column=0, row=1)
MIDInput.grid(column=0, row=2)
Button(root, text="Generate ID", command=MemeIDPopUp).grid(column=0, row=4, pady=10)
Button(root, text="Close Generator", command=root.destroy).grid(column=0, row=5)

root.mainloop()

